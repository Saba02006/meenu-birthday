document.addEventListener("DOMContentLoaded", function () {

    // =========================================
    // MUSIC
    // =========================================

    const happyBirthdayMusic =
        document.getElementById("happyBirthdayMusic");
    const specialSong =
        document.getElementById("specialSong");

    // Song 2 is started only once and then continues through Screens 2–6.
    let specialSongStarted = false;
let song3Started = false;


    // =========================================
    // GET ELEMENTS
    // =========================================

    const noBtn = document.getElementById("noBtn");
    const yesBtn = document.getElementById("yesBtn");

    const welcome = document.getElementById("welcome");

    const birthdayScreen =
        document.getElementById("birthdayScreen");

    const letsGoBtn =
        document.getElementById("letsGoBtn");

    const memoryScreen =
        document.getElementById("memoryScreen");

    const memoryNextBtn =
        document.getElementById("memoryNextBtn");

    const letterScreen =
        document.getElementById("letterScreen");

    const envelopeArea =
        document.getElementById("envelopeArea");

    const letterPaper =
        document.getElementById("letterPaper");

    const letterNextBtn =
        document.getElementById("letterNextBtn");

    const reasonsScreen =
        document.getElementById("reasonsScreen");

    const lastSurpriseBtn =
        document.getElementById("lastSurpriseBtn");

    const finalScreen =
        document.getElementById("finalScreen");


    // =========================================
    // NO BUTTON
    // =========================================

    const noMessages = [
        "NO 😭",
        "Are you sure? 👀",
        "Nice try 😂",
        "NOPE! 🏃‍♀️",
        "Catch me! 😭",
        "JUST CLICK YESS 💗"
    ];

    let noCount = 0;


    function moveNoButton() {

        noCount++;

        noBtn.textContent =
            noMessages[
                Math.min(
                    noCount,
                    noMessages.length - 1
                )
            ];

        noBtn.style.position = "fixed";

        const buttonWidth = noBtn.offsetWidth;
        const buttonHeight = noBtn.offsetHeight;

        const padding = 30;

        const maxX =
            window.innerWidth -
            buttonWidth -
            padding;

        const maxY =
            window.innerHeight -
            buttonHeight -
            padding;

        const randomX =
            Math.random() *
            (maxX - padding) +
            padding;

        const randomY =
            Math.random() *
            (maxY - padding) +
            padding;

        noBtn.style.left =
            randomX + "px";

        noBtn.style.top =
            randomY + "px";
    }


    noBtn.addEventListener(
        "mouseenter",
        moveNoButton
    );


    noBtn.addEventListener(
        "touchstart",
        function (event) {

            event.preventDefault();

            moveNoButton();

        },
        { passive: false }
    );


    noBtn.addEventListener(
        "click",
        function (event) {

            event.preventDefault();

            moveNoButton();

        }
    );


    // =========================================
    // SCREEN 1 → SCREEN 2
    // YESS BUTTON
    // =========================================

    yesBtn.addEventListener(
        "click",
        function () {

            // 🎂 SONG 1 — HAPPY BIRTHDAY
            // The YESS click is a real user interaction, so the
            // browser allows the birthday music to start.

            happyBirthdayMusic.currentTime = 0;

            happyBirthdayMusic.play().catch(function (error) {
                console.log(
                    "Happy Birthday music error:",
                    error
                );
            });


            // Fade Screen 1

            welcome.style.opacity = "0";

            welcome.style.transform =
                "scale(0.95)";


            // Show Screen 2

            setTimeout(function () {

                welcome.style.display = "none";

                birthdayScreen.classList.add(
                    "active"
                );

            }, 700);

        }
    );


    // =========================================
    // SCREEN 2 → SCREEN 3
    // LET'S GO BUTTON
    // =========================================

    letsGoBtn.addEventListener(
        "click",
        function () {

            // Stop Happy Birthday music

            happyBirthdayMusic.pause();

            happyBirthdayMusic.currentTime = 0;


            // 🎵 SONG 2 — SPECIAL SONG
            //
            // Start it once when leaving Screen 2.
            // After this, Screens 3–6 NEVER pause or restart it.
            // It therefore keeps the exact playback position while
            // the screens change.

            if (!specialSongStarted) {

                specialSongStarted = true;

                // Play ONLY the 1:11 → 1:26 section.
                // 1:11 = 71 seconds.
                specialSong.currentTime = 71;

                specialSong.play().catch(function (error) {
                    console.log("Special song error:", error);
                });
            }


            // =========================================
            // SPECIAL SONG — PLAY ONLY 1:11 → 1:26
            // =========================================
            // 1:11 = 71 seconds
            // 1:26 = 86 seconds
            // When it reaches 1:26, jump back to 1:11.

            specialSong.addEventListener("timeupdate", function () {

                if (specialSong.currentTime >= 86) {

                    specialSong.currentTime = 71;

                    if (specialSong.paused) {
                        specialSong.play().catch(function (error) {
                            console.log("Special song loop error:", error);
                        });
                    }
                }

            });


            // Fade Screen 2

            birthdayScreen.style.opacity = "0";

            birthdayScreen.style.transform =
                "scale(0.95)";


            // Show Screen 3

            setTimeout(function () {

                birthdayScreen.style.display =
                    "none";

                memoryScreen.classList.add(
                    "active"
                );

            }, 700);

        }
    );


    // =========================================
    // SCREEN 3 → SCREEN 4
    // MEMORY NEXT BUTTON
    // =========================================
    // Song 2 continues — do NOT pause or restart it.

    memoryNextBtn.addEventListener(
        "click",
        function () {

            // Fade Screen 3

            memoryScreen.style.opacity = "0";

            memoryScreen.style.transform =
                "scale(0.95)";


            setTimeout(function () {

                // Hide Screen 3

                memoryScreen.style.display =
                    "none";


                // Show Screen 4

                letterScreen.classList.add(
                    "active"
                );

            }, 700);

        }
    );


    // =========================================
    // SCREEN 4
    // OPEN ENVELOPE
    // =========================================

    envelopeArea.addEventListener(
        "click",
        function () {

            // Prevent opening twice

            if (
                envelopeArea.classList.contains(
                    "open"
                )
            ) {
                return;
            }


            // Open envelope

            envelopeArea.classList.add(
                "open"
            );


            // Show letter

            setTimeout(function () {

                letterPaper.classList.add(
                    "show"
                );

            }, 800);


            // Show next button

            setTimeout(function () {

                letterNextBtn.classList.add(
                    "show"
                );

            }, 2300);

        }
    );


    // =========================================
    // SCREEN 4 → SCREEN 5
    // LETTER NEXT BUTTON
    // =========================================
    // Song 2 continues — do NOT pause or restart it.

    letterNextBtn.addEventListener(
        "click",
        function () {

            // Fade Screen 4

            letterScreen.style.opacity = "0";

            letterScreen.style.transform =
                "scale(0.95)";


            setTimeout(function () {

                // Hide Screen 4

                letterScreen.style.display =
                    "none";


                // Show Screen 5

                reasonsScreen.classList.add(
                    "active"
                );

            }, 700);

        }
    );


    // =========================================
    // SCREEN 5 → SCREEN 6
    // LAST SURPRISE BUTTON
    // =========================================
    // Song 2 continues — do NOT pause or restart it.

    lastSurpriseBtn.addEventListener(
        "click",
        function () {

            // Fade Screen 5

            reasonsScreen.style.opacity = "0";

            reasonsScreen.style.transform =
                "scale(0.95)";


            setTimeout(function () {

                // Hide Screen 5

                reasonsScreen.style.display =
                    "none";


                // Show Screen 6

                finalScreen.classList.add(
                    "active"
                );

            }, 800);

        }
    );


    // =========================================
    // EXTRA FLOATING HEARTS & STARS
    // =========================================

    const backgroundEffects =
        document.getElementById(
            "backgroundEffects"
        );


    const magicalSymbols = [
        "♡",
        "✦",
        "✧",
        "♥",
        "✨",
        "♡",
        "✦",
        "⋆"
    ];


    for (let i = 0; i < 18; i++) {

        const particle =
            document.createElement("span");


        particle.textContent =
            magicalSymbols[
                Math.floor(
                    Math.random() *
                    magicalSymbols.length
                )
            ];


        particle.style.left =
            Math.random() * 100 + "%";


        particle.style.top =
            Math.random() * 100 + "%";


        particle.style.animationDuration =
            (7 + Math.random() * 8) + "s";


        particle.style.animationDelay =
            Math.random() * 6 + "s";


        particle.style.fontSize =
            (12 + Math.random() * 14) + "px";


        backgroundEffects.appendChild(
            particle
        );

    }

});